import { useState, useEffect, useCallback } from 'react';
import { setupInterview } from '../api/interviewSetup';
import { getJobCategories } from '../api/jobCategories';
import { InterviewSetupResponse } from '../api/types';

export interface AudioAnalysisResult {
  text: string;
  emotion: string;
  probabilities: Record<string, number>;
}

export function useInterview() {
  
  const [jobCategories, setJobCategories] = useState<string[]>([]);
  const [selectedJob, setSelectedJob] = useState<string>('');
  const [numQuestions, setNumQuestions] = useState<number>(3);
  const [interviewSession, setInterviewSession] = useState<InterviewSetupResponse | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [step, setStep] = useState<'setup' | 'interview' | 'results'>('setup');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [chatMessages, setChatMessages] = useState<Array<{ type: 'question' | 'answer'; text: string; number: number; timestamp: string }>>([]);
  const [cameraOn, setCameraOn] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [voiceResult, setVoiceResult] = useState<string>('분석 대기 중');
  const [audioAnalysisResult, setAudioAnalysisResult] = useState<AudioAnalysisResult | null>(null);

  // 초기 직무 카테고리 로드
  useEffect(() => {
    getJobCategories()
      .then(data => {
        setJobCategories(data.categories);
        setSelectedJob(data.categories[0] || '');
      })
      .catch(() => alert('직무 카테고리를 불러오지 못했습니다.'));
  }, []);

  const addMessage = useCallback(
    (type: 'question' | 'answer', text: string, number: number) => {
      const timestamp = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
      setChatMessages(prev => [...prev, { type, text, number, timestamp }]);
    },
    []
  );

  const startInterview = useCallback(async () => {
    if (!selectedJob) return;
    setIsLoading(true);
    setCameraOn(true);
    try {
      const session = await setupInterview(selectedJob, numQuestions);
      setInterviewSession(session);
      setStep('interview');
      setCurrentQuestionIndex(0);
      setChatMessages([
        { type: 'question', text: 'AI 면접을 시작합니다.', number: 0, timestamp: new Date().toLocaleTimeString('ko-KR') },
        { type: 'question', text: session.questions[0], number: 1, timestamp: new Date().toLocaleTimeString('ko-KR') }
      ]);
    } catch {
      alert('면접 시작에 실패했습니다.');
    } finally {
      setIsLoading(false);
    }
  }, [selectedJob, numQuestions]);

  const nextQuestion = useCallback(() => {
    if (!interviewSession) return;
    const next = currentQuestionIndex + 1;
    if (next < interviewSession.questions.length) {
      setCurrentQuestionIndex(next);
      addMessage('question', interviewSession.questions[next], next + 1);
    } else {
      setStep('results');
      setIsRecording(false);
      addMessage('question', '모든 질문이 완료되었습니다.', next + 1);
    }
  }, [currentQuestionIndex, interviewSession]);

  const handleVoiceResult = useCallback(
    (result: AudioAnalysisResult) => {
      setVoiceResult(result.text);
      setAudioAnalysisResult(result);
      addMessage('answer', result.text, currentQuestionIndex + 1);
      nextQuestion();
    },
    [currentQuestionIndex, nextQuestion]
  );

  const toggleRecording = useCallback(() => setIsRecording(prev => !prev), []);
  const onCameraReady = useCallback(() => setCameraOn(true), []);

  return {
    jobCategories,
    selectedJob,
    setSelectedJob,
    numQuestions,
    setNumQuestions,
    step,
    isLoading,
    startInterview,
    interviewSession,
    cameraOn,
    isRecording,
    voiceResult,
    audioAnalysisResult,
    chatMessages,
    handleVoiceResult,
    toggleRecording,
    onCameraReady
  };
}